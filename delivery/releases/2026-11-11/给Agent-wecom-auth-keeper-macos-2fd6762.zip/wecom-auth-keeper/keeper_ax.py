"""Small native AX adapter. No bridge imports, configuration or network access."""
import time
from contextlib import contextmanager
from keeper_common import KeeperError
from AppKit import NSWorkspace, NSPasteboard, NSPasteboardItem, NSPasteboardTypeString
from ApplicationServices import (
    AXIsProcessTrusted, AXUIElementCopyAttributeValue, AXUIElementCreateApplication,
    AXUIElementPerformAction, AXUIElementCopyActionNames, AXUIElementSetAttributeValue,
    AXUIElementIsAttributeSettable, AXValueGetValue, kAXValueCGPointType, kAXValueCGSizeType,
    AXUIElementCopyElementAtPosition, AXUIElementCreateSystemWide,
)
from Quartz import (
    CGEventCreateMouseEvent, CGEventPost, CGPoint, kCGEventLeftMouseDown,
    kCGEventLeftMouseUp, kCGHIDEventTap,
    CGEventCreateKeyboardEvent, CGEventSetFlags, CGEventPostToPid, kCGEventFlagMaskCommand,
)


def require_search_focus(native, app, window, element):
    """Keyboard input is limited to a verified native search field, never a composer."""
    front = NSWorkspace.sharedWorkspace().frontmostApplication()
    if (front is None or front.processIdentifier() != native.processIdentifier()
            or ax_get(app, "AXFocusedWindow") != window
            or ax_get(app, "AXFocusedUIElement") != element
            or ax_get(element, "AXRole") != "AXTextField"):
        raise KeeperError("navigation_focus_lost", "Search focus changed; navigation stopped")


def search_key(native, app, window, element, code, flags=0):
    require_search_focus(native, app, window, element)
    for down in (True, False):
        event = CGEventCreateKeyboardEvent(None, code, down)
        CGEventSetFlags(event, flags)
        CGEventPostToPid(native.processIdentifier(), event)
        time.sleep(0.05)


@contextmanager
def temporary_clipboard(text):
    """Preserve all pasteboard formats; do not overwrite a concurrent user's copy."""
    board = NSPasteboard.generalPasteboard()
    saved = []
    for source in board.pasteboardItems() or []:
        item = NSPasteboardItem.alloc().init()
        for kind in source.types():
            data = source.dataForType_(kind)
            if data is not None:
                item.setData_forType_(data, kind)
        saved.append(item)
    board.clearContents()
    board.setString_forType_(text, NSPasteboardTypeString)
    own_change = board.changeCount()
    try:
        yield
    finally:
        if board.changeCount() == own_change:
            board.clearContents()
            if saved:
                board.writeObjects_(saved)


def replace_search(native, app, window, element, text):
    click(element, window)
    time.sleep(0.15)
    require_search_focus(native, app, window, element)
    with temporary_clipboard(text):
        for attempt in range(2):
            # A just-switched organization can ignore the first paste while its
            # search view initializes. Retry once, only in the same verified field.
            require_search_focus(native, app, window, element)
            if NSPasteboard.generalPasteboard().stringForType_(NSPasteboardTypeString) != text:
                raise KeeperError("navigation_input_failed", "Clipboard changed during search")
            search_key(native, app, window, element, 0, kCGEventFlagMaskCommand)
            search_key(native, app, window, element, 9, kCGEventFlagMaskCommand)
            deadline = time.monotonic() + 3
            while ax_get(element, "AXValue") != text:
                require_search_focus(native, app, window, element)
                if time.monotonic() >= deadline:
                    break
                time.sleep(0.05)
            else:
                return
        raise KeeperError("navigation_input_failed", "Search text was not accepted")


def submit_search(native, app, window, element, expected):
    if ax_get(element, "AXValue") != expected:
        raise KeeperError("navigation_input_failed", "Search text changed before selection")
    search_key(native, app, window, element, 36)  # Return; only while search has focus


def composer_key(native, app, window, element, code, flags=0):
    """Installer-only input; caller also verifies the exact target chat per key."""
    front = NSWorkspace.sharedWorkspace().frontmostApplication()
    if (front is None or front.processIdentifier() != native.processIdentifier()
            or ax_get(app, 'AXFocusedWindow') != window
            or ax_get(app, 'AXFocusedUIElement') != element
            or ax_get(element, 'AXRole') != 'AXTextArea'
            or not ax_settable(element, 'AXValue')):
        raise KeeperError('entry_composer_focus_lost', 'Composer focus changed; no more input')
    for down in (True, False):
        event = CGEventCreateKeyboardEvent(None, code, down)
        CGEventSetFlags(event, flags)
        CGEventPostToPid(native.processIdentifier(), event)
        time.sleep(.05)


def paste_composer(native, app, window, element, text):
    if ax_get(element, 'AXValue') not in ('', None):
        raise KeeperError('entry_draft_present', 'Existing draft preserved; no paste')
    with temporary_clipboard(text):
        if NSPasteboard.generalPasteboard().stringForType_(NSPasteboardTypeString) != text:
            raise KeeperError('entry_clipboard_changed', 'Prepared entry clipboard changed')
        composer_key(native, app, window, element, 9, kCGEventFlagMaskCommand)


def submit_composer(native, app, window, element, expected):
    if ax_get(element, 'AXValue') != expected:
        raise KeeperError('entry_draft_changed', 'Prepared entry draft changed; no send')
    composer_key(native, app, window, element, 36)


def ax_get(element, attribute):
    error, value = AXUIElementCopyAttributeValue(element, attribute, None)
    return value if error == 0 else None


def ax_perform(element, action):
    return AXUIElementPerformAction(element, action)


def ax_set(element, attribute, value):
    return AXUIElementSetAttributeValue(element, attribute, value)


def ax_settable(element, attribute):
    error, value = AXUIElementIsAttributeSettable(element, attribute, None)
    return error == 0 and bool(value)


def action_names(element):
    error, actions = AXUIElementCopyActionNames(element, None)
    return list(actions or []) if error == 0 else []


def frame(element):
    position, size = ax_get(element, "AXPosition"), ax_get(element, "AXSize")
    if position is None or size is None:
        return None
    try:
        ok1, point = AXValueGetValue(position, kAXValueCGPointType, None)
        ok2, extent = AXValueGetValue(size, kAXValueCGSizeType, None)
        if ok1 and ok2:
            return float(point.x), float(point.y), float(extent.width), float(extent.height)
    except (TypeError, ValueError):
        pass
    return None


def click(element, window, *, allow_coordinate_fallback=True):
    bounds, outer = frame(element), frame(window)
    if not bounds or not outer:
        raise RuntimeError("Element geometry unavailable")
    error, actions = AXUIElementCopyActionNames(element, None)
    actions = actions if error == 0 else []
    if "AXScrollToVisible" in actions:
        ax_perform(element, "AXScrollToVisible")
        # WebKit updates geometry asynchronously after scrolling.
        for _ in range(20):
            bounds = frame(element)
            if bounds and outer[1] <= bounds[1] and bounds[1] + bounds[3] <= outer[1] + outer[3]:
                break
            time.sleep(0.05)
    if not bounds:
        raise RuntimeError("Element geometry unavailable after scrolling")
    x, y, w, h = bounds
    wx, wy, ww, wh = outer
    cx, cy = x + w / 2, y + h / 2
    if w <= 0 or h <= 0 or not (wx <= cx <= wx + ww and wy <= cy <= wy + wh):
        raise RuntimeError("Element outside target window; scroll it into view first")
    if "AXPress" in actions and ax_perform(element, "AXPress") == 0:
        return
    if not allow_coordinate_fallback:
        raise KeeperError("ax_press_failed", "Target control did not accept its native press action")
    for kind in (kCGEventLeftMouseDown, kCGEventLeftMouseUp):
        CGEventPost(kCGHIDEventTap, CGEventCreateMouseEvent(None, kind, CGPoint(cx, cy), 0))
        time.sleep(0.05)


def open_revoke_confirmation(native, app, window, page, element):
    """5.0.13's text-only menu opens a confirmation; never clicks that button.

    The caller binds the page/row and owns the desktop lease. No guessed
    position: require a live native menu element and system-wide hit testing.
    Final revoke and grant continue to require AXPress.
    """
    def verify():
        front = NSWorkspace.sharedWorkspace().frontmostApplication()
        if (client_version(native) != '5.0.13' or front is None
                or front.processIdentifier() != native.processIdentifier()
                or ax_get(app, 'AXFocusedWindow') != window
                or window not in (ax_get(app, 'AXWindows') or [])
                or ax_get(element, 'AXRole') != 'AXStaticText'
                or (ax_get(element, 'AXTitle') or ax_get(element, 'AXValue')) != '取消授权'
                or 'AXPress' in action_names(element)):
            raise KeeperError('revoke_menu_unverified', 'Expected the focused versioned text-only revoke menu')
        bounds, outer = frame(element), frame(page)
        if not bounds or not outer:
            raise KeeperError('revoke_menu_unverified', 'Menu geometry unavailable')
        x,y,w,h = bounds; ox,oy,ow,oh = outer
        if not (w > 0 and h > 0 and ox <= x and oy <= y and x+w <= ox+ow and y+h <= oy+oh):
            raise KeeperError('revoke_menu_unverified', 'Menu outside bound page')
        center = (x+w/2, y+h/2)
        error, hit = AXUIElementCopyElementAtPosition(AXUIElementCreateSystemWide(), *center, None)
        if error != 0 or hit != element:
            raise KeeperError('revoke_menu_occluded', 'System hit test did not identify the same menu element')
        return center
    center = verify()
    if verify() != center:
        raise KeeperError('revoke_menu_unverified', 'Menu moved before navigation')
    for kind in (kCGEventLeftMouseDown, kCGEventLeftMouseUp):
        CGEventPost(kCGHIDEventTap, CGEventCreateMouseEvent(None, kind, CGPoint(*center), 0))
        time.sleep(.05)


def application():
    if not AXIsProcessTrusted():
        # Check in this exact process, without prompting or attempting to grant
        # access. A terminal's permission is not proof about a launchd child.
        raise KeeperError("accessibility_permission_unavailable", "Accessibility access is unavailable to this process", 3)
    apps = [a for a in NSWorkspace.sharedWorkspace().runningApplications() if a.bundleIdentifier() == "com.tencent.WeWorkMac"]
    if not apps:
        raise KeeperError("wecom_not_running", "No running WeCom application was found", 3)
    apps = [a for a in apps if ax_get(AXUIElementCreateApplication(a.processIdentifier()), "AXWindows")]
    if not apps:
        raise KeeperError("wecom_window_unavailable", "No WeCom window is accessible in this session")
    if len(apps) > 1:
        raise KeeperError("wecom_multiple_instances", "Multiple windowed WeCom instances are accessible")
    return apps[0], AXUIElementCreateApplication(apps[0].processIdentifier())


def activate(app):
    app.activateWithOptions_(1 << 1)


def client_version(native):
    from Foundation import NSBundle
    bundle = NSBundle.bundleWithURL_(native.bundleURL())
    return str(bundle.objectForInfoDictionaryKey_('CFBundleShortVersionString') or '')


def open_organization_menu(native, app, window):
    """Calibrated 5.0.13 entry only; caller verifies semantic corp rows after click."""
    front = NSWorkspace.sharedWorkspace().frontmostApplication()
    if (client_version(native) != '5.0.13' or front is None
            or front.processIdentifier() != native.processIdentifier()
            or window not in (ax_get(app, 'AXWindows') or [])):
        raise KeeperError('org_switcher_not_found', 'Organization entry focus/version changed')
    bounds = frame(window)
    if not bounds or bounds[2] < 500 or bounds[3] < 400:
        raise KeeperError('org_switcher_not_found', 'Unexpected sidebar geometry')
    x, y, width, height = bounds
    for kind in (kCGEventLeftMouseDown, kCGEventLeftMouseUp):
        CGEventPost(kCGHIDEventTap, CGEventCreateMouseEvent(None, kind, CGPoint(x + 30, y + height - 30), 0))
        time.sleep(0.1)
