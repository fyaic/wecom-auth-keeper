# 首次接入：先准备 Bot、组织和私聊入口

本文件供安装 Agent 执行。业务人员只需说明要服务的企业和业务能力；Bot 名称或配置能在本机确认时，由 Agent 查询，不让业务人员抄 ID、链接、Secret 或命令。首次接入可由 Agent 操作界面；以后的定时续期必须由脚本独立完成。

**本分发方案只在登录 Bot 创建者主账号的设备上，维护这个主账号自己创建的 Bot。** 第1步读取已有CLI，第2步用官方页面核对桌面身份和组织，先确认这个前提。普通业务成员设备即使已有CLI绑定也不能冒充创建者续期；不满足时保留绑定，不安装周期任务、不为通过验收切换其他服务使用的账号。

**首次设备没有 Bot 私聊、没有续期链接是正常初始状态。此时不运行历史搜索，也不运行定时续期。** 按下面顺序建立入口。

## 1. 先确定本机要维护的 Bot

先记录用户明确指定的Bot与组织；用户目标优先于业务服务配置，业务服务配置优先于终端默认值。用户指定测试Bot时，不能因默认CLI已绑定业务Bot就改变测试对象。再盘点本机已知CLI/profile路径；不要为找配置读取Secret/凭据文件，也不要修改业务服务。

先收集当前`WECOM_CLI_CONFIG_DIR`与已知业务启动配置中使用的profile路径（只取路径不读凭据），并显式传给`--profile`。工具默认只查真正default，不沿用环境覆盖、不自动扫描其他目录。

先查已知 CLI profile：`delivery/profiles.py` 只调用官方接口，原始身份存到包外私有文件。正确身份命令是 `wecom-cli identity whoami`，不是 `wecom-cli whoami`。`auth show --status` 的 authorized 只表示 CLI 已绑定，不代表业务权限未过期。

**先盘点既有配置，不重新扫码，也不自动选择默认绑定。** 运行：

```bash
python3 delivery/profiles.py --cli /absolute/path/wecom-cli --profile /absolute/known/profile --output /absolute/private/profiles.json
```

profiles通过查询前后两次`auth show`记录稳定Bot ID；默认配置只是候选，报告`target_selected=false`。随后执行第2步，从用户指定Bot的原生详情/官方页取得身份，再按ID反查profile。不要将默认业务Bot的拒绝结果当成测试Bot的结果。

CLI已绑定但权限过期、昵称不同、暂时找不到Bot或私聊，都不是重新绑定的理由。**目标Bot已存在但尚未找到匹配CLI**是另一种接入状态：继续核对该Bot的现有配置/官方接入方式，保留其他Bot，不要求重建目标，也不能用另一个authorized profile凑数。确需首次绑定的步骤另行按实际官方流程与用户授权处理，不能伪装成日常续期。

| 设备状态 | Agent 应做什么 |
| --- | --- |
| 业务目标与已有 CLI Bot 一致 | 复用该 profile；继续确认所属组织。不要重建 Bot 或覆盖凭据。 |
| 有多个组织或多个 CLI profile | 列出本机查到的企业/Bot 候选，结合业务目标选定；不要默认取第一个 profile，也不要把同名当成同一身份。 |
| 确认目标 Bot 没有已有 CLI 绑定，且用户明确要求首次接入 | 另行完成官方接入；保留其他 Bot 配置。不能因为暂时没有定位到现有 Bot，就擅自进入扫码分支。 |
| 没有可用 Bot | 帮用户在目标企业的官方机器人入口创建或接入一个 Bot。确认新权限范围后再操作；没有创建权限时明确需要该企业提供 Bot/名片，不能拿另一个企业的 Bot 凑数。 |

首次创建、首次绑定、首次授予业务权限与“续期已有权限”分开记录。工具不能替没有权限的成员创建企业资源，不能扩大权限来让验收变绿。CLI profile、Bot、所属组织确认后，同一轮安装不再反复问用户“用哪个 Bot”。

### 目标已创建，但本机尚未接入这个 Bot

这是本轮远端测试设备的真实初始状态，不能改用其他已绑定的业务Bot。先完成第2步的官方身份核验，并保留`target_profile_not_found`与实际检查范围；它只说明目标配置尚未匹配。

本机官方CLI 1.3.0的`auth init --help`提供`--manual`，可以使用已有Bot的Bot ID与Secret接入，**首次接入不等于必须扫码**。目标已是API模式时，安装Agent应先从该目标的官方“API配置”确认现有字段，而不是重建Bot、重置Secret或要求业务人员手抄凭据。

用户已要求安装这个Bot且确认没有匹配绑定时，可以准备单独的新profile，不覆盖默认目录或业务服务配置。现有API凭据仅在本机受控进程中传给官方CLI；不进入Agent上下文、命令行参数、终端录屏、诊断输出或ZIP，不读取其他profile的加密凭据。首次接入所需的目标凭据处理与前面的只读配置盘点分开；盘点阶段仍禁止读取Secret。若必须新启用API、重置凭据或扩大权限，先展示具体操作并取得对应授权，不能用这些动作修复导航失败。

手动接入的交互细节须按实际CLI验证：不能仅凭帮助文案假定普通stdin可用，也不能把Secret写进带回显的PTY日志。完成后用官方`auth show`与`identity whoami`重验新profile属于原目标，并重验原有profile未变；再重新运行profiles与select_target。**接入成功仍不是业务权限授权或续期成功。**

## 2. 确认组织与 Bot 身份，先不依赖聊天记录

还没有 Bot 配置时也能诊断当前界面，不需要编造 ID。先在界面打开企业菜单或通讯录 Bot 列表，再使用本版本实际执行 Python：

```bash
.venv/bin/python delivery/gui.py --action inspect-expanded --python "$PWD/.venv/bin/python3" --evidence-dir "$HOME/.local/state/wecom-auth-keeper/setup-inspect-1"
```

这是同用户 GUI launchd 的只读临时任务；`--python` 只用于无配置的 inspect/inspect-expanded，不能用于续期或覆盖配置中的执行主体。它读取当前可见的原生组织菜单、通讯录 Bot 名称候选和页面标志，不导航、不发送、不授权、不读取凭据。未打开企业菜单时，菜单结果为空不代表没有组织；未展开/滚动完整列表时不能排除未显示的 Bot。结果保存在包外本机私有目录。

1. 在企业微信原生企业菜单读取准确名称及选中标记。业务企业全称与菜单简称分别保存；不要用头像、人名、聊天里提到的企业名判断当前组织。
2. 切到目标组织，从“机器人”目录、通讯录中的机器人或已知 Bot 名片打开详情。5.0.13 门户中应优先查看“查看更多机器人”或现有机器人卡片；“查看更多机器人”实际跳到通讯录的“智能机器人”分组，侧栏可能选中“更多”，不是“我的机器人”管理卡片页。读取分组下的 Bot 行（包括“企业创建的”），按需展开/滚动，不能拿卡片尺寸筛选通讯录列表。不要只看“管理机器人”。能管理的 Bot 可走“管理机器人”；管理列表不包含所有可使用 Bot，列表空不代表 Bot 不存在。
3. 打开候选 Bot 的官方“可使用权限”页；如果资料页没有权限入口，可先从带原生 Bot 标记的通讯录行进入空私聊，再打开聊天中的机器人资料/权限入口。这属于只读定位，身份匹配前不发送消息、不授权、不保存为已通过目标。将 URL 的 `aibotid`、`str_aibotid` 与选定 CLI/官方链接核对。两个组织中的 Bot 分别处理。名称可能变更，最终绑定依靠身份；没有匹配时不改 CLI 去迁就当前页面。
4. CLI授权真人与当前组织显示名不同时，可能是组织别名；用既有 CLI 的官方身份和该原链接打开后的页面提示核验。不能仅凭名字差异断言不同账号，不通过新扫码“证明”身份，也不能拿另一 Bot 的权限页冒充当前 CLI 的续期证据。
5. 保存本机映射：CLI profile → Bot 双 ID → 当前 Bot 显示名 → 业务企业名称 → 原生企业菜单准确名称 → 需要维护的权限。原始 ID/URL 只存私有配置。

原生身份取得后，由Agent将实际观察写入包外`target.json`：`selection_source`为`user_request`（用户未指定而业务服务已明确时才用`business_service`），`identity_source`为`native_selected_bot_permission_page`，并记录`bot_chat_name`、`organization_selector_name`和原始`authorization_url`。这些字段由Agent从已指定目标读取，不让业务人员填写技术标识；这是安装记录，不是独立的身份认证证明。

```bash
python3 delivery/select_target.py --target /absolute/private/target.json --profiles /absolute/private/profiles.json --output /absolute/private/selection.json
python3 delivery/existing_entry.py --selection /absolute/private/selection.json --cli /absolute/path/wecom-cli --node /absolute/path/node --output /absolute/private/existing-entry.json
```

只有唯一ID匹配才返回`target_profile_selected`；无匹配是`target_profile_not_found`（仅代表已检查配置范围），多份匹配是`target_profile_ambiguous`，都不会自动选择默认项。消歧时按已知业务配置或明确用户选择，增加`--profile /absolute/known/profile`或`--default-profile`重新选择；只允许在已盘点、ID匹配且authorized的候选中收窄，不改Bot目标。existing_entry从selection指定的profile读取，并在业务只读调用前再次核对Bot ID；漂移返回`requested_target_mismatch`。若消息权限过期，从官方850003响应取完整原链接；已绑定但从未授予消息权限的850002同样可取官方链接，明确记录not_authorized与authorization_baseline_required，不自动首次授权。健康权限未返回链接时保留已读到的官方UI入口，不制造写入错误取链。URL的type、原生参数和编码逐字保留，不重组为固定type=1。取链不代替创建者/组织/私聊核验。

5.0.13 可能恢复上次机器人子页面：先辨认“智能机器人”门户、“我的机器人”列表、“机器人详情”或权限弹窗，再决定下一步。切页后原生 AX 树可能需要重新请求展开；单纯保持 AXEnhancedUserInterface=true 不证明新树可读。`inspect-expanded` 是诊断手段，不能把搜索框里自己输入的 Bot 名称当作已找到 Bot。Bridge 的组织接口返回 success/缓存当前组织也不代替原生选中标记。

通讯录中的 Bot 行可能先打开“机器人资料”，管理列表则可能打开“机器人详情”；按实际页面辨认“发消息/去使用”和“可使用权限”，不要把两条路径混成一个模板。加载等待必须等待明确的新页面标志或可读列表，不能把 unknown 当成完成条件；结构未识别不等于列表为空。

部分组织的门户没有“查看更多机器人”，此时从侧栏 **更多 → 通讯录 → 智能机器人** 进入目录。首次接入由安装 Agent 按实际界面操作；不同组织侧栏项目数量和位置可变，“更多”也可能在功能列表外，不能套固定行号或遍历邮件、日程等无关功能。展开菜单后重新读取“通讯录”项，菜单消失时先重新定位。分组折叠、列表仅当前可见或一次滚动内容未变，都不能据此声明 Bot 不存在。只记录明确读到的候选与仍未知的范围。

没有私聊时，不要遍历企业反复搜索 `authorizationList`；还没有发过的链接不可能从历史里找到。

找不到同名 Bot 时，不要立即判断不存在或让用户重新选 Bot。先核对目录范围与业务服务使用的 profile；候选数量有限时，可只读查看官方资料/权限页排除改名，最终以身份匹配为准。若仍不能把现有 CLI Bot 对应到当前桌面可用 Bot，保留“组织/桌面身份未核验”状态，并记录具体页面/官方错误证据。不要无休止换入口、换绑原配置或擅自另建 Bot。已有业务目标明确时，不重复问“选哪个 Bot”，也不让用户寻找技术 ID。

### 已有官方链接，但还没找到 Bot 私聊

不要把“必须先找到 Bot 私聊”变成无法诊断身份的循环。先复用本机已有的准确官方链接；若原生资料入口不可达，在用户授权的诊断范围内，可将原链接临时放入**已确认属于当前账号的“自己”会话**，用于打开只读页面。需核对本人资料与进入路径，不能只凭同名标题，也不能发送给他人、群或另一 Bot。不默认采用这种载体作为正式续期入口，不据此签发私聊入口回执。

写入时先保留已有草稿，逐字核对输入值与原链接一致，再核验接收会话和焦点后发送一次并读回；远程键盘可能丢失 `?`、`_` 等字符，不应重复盲打。消息既已存在就复用。用绑定双 ID 的页读取结果并关闭；`open -a` 返回0、出现 AXWebArea 或只有“可使用权限”标题都不代表内容加载完成。等待可读权限行或明确官方错误，不因空白重建 CLI。

官方页出现“暂无法授权，仅限机器人创建者可进行授权”时，脚本返回 `authorization_creator_required`；“当前账号非机器人所属企业”对应 `authorization_organization_mismatch`；“机器人已删除”对应 `authorization_bot_deleted`。这三项与过期、导航失败分别处理。先核对原生组织选中项，在已有业务目标范围内有界验证正确组织；仍受限时，保留 CLI，由 Bot 创建者使用具备权限的桌面身份/设备完成安装。**不通过换绑、扫码新建 profile、点击其他 Bot 或修改客户端权限来绕过官方身份限制。** 未实测的组织保留 unknown，不能仅凭昵称判定账号不符。

如果错误页显示创建者姓名，可从该**已绑定页面内唯一可核验的资料入口**只读查看创建者组织/部门线索；姓名可能是分段AXStaticText并带AXPress，不能因整句不同漏掉限制。只读所需身份线索，不点“发消息/添加联系人/编辑”，关闭本轮资料浮层和权限页并确认主窗口保留。组织名称或部门路径只是定位线索，不能冒充企业ID匹配。CLI绑定证明API身份，桌面登录态证明UI身份；两者必须具备对应权限。已有其他桌面服务时，不擅自切换登录账号来通过测试。

`inspect-expanded` 可只读报告当前官方页的 `blocking_error`，无配置时不能证明它属于选定 CLI。具有正确配置时的 `check-existing`/入口核验/维护都会检查绑定页错误；入口核验失败仍自动关页，不写成功回执。诊断结束后，回到已核验 Bot 私聊准备正式入口，再单独验续期与定时。

## 3. 从已核验 Bot 建立私聊，准备一次入口

1. 关闭权限页，回到同一Bot详情，从原生单聊入口建立**本机当前账号与这个Bot的私聊**。5.0.13实测可能是两步：管理详情的“去使用”→通讯录机器人资料→资料页的“发消息”。资料页有“由我创建”“个人使用机器人”“去管理”以及“发消息/添加到群聊”；这还不是聊天。点“发消息”是进入私聊的导航，不是权限页的“授权”，不能点“添加到群聊”。若第2步已实际进入私聊则复用，不重复建入口。
2. 安装Agent核对进入路径、消息视图、真实聊天标题、消息区域和底部输入框。通讯录选中的Bot行、全局搜索框或任意AXTextArea均不能证明已经进入私聊；不能把它们当作聊天标题/发送输入框。仅名称匹配也不证明是私聊，不在同名群、本人诊断会话或其他人的私聊发送。inspect的bot_contact_profile_hint提示资料页，private_chat_verified始终为false，不能冒充安装观察。
   在真实私聊调用 `gui.py --action inspect-expanded --python <已授权的绝对Python路径> --evidence-dir <新私有目录>`，记录 `message_view_verified=true` 与 `native_chat_header`。**配置采用实际原生 AX 标题**，不要从截图猜空格；5.0.13 实测视觉显示“续期测试 bot”，AX标题却为“续期测试bot”。这不是另一个Bot，也不是把全部名字去空格匹配的理由。须保留第2步已核验的双ID、CLI与组织，仅修正记录的实际聊天名，重新生成selection与草稿；绝不自动改选目标。`private_chat_verified=false`仍提醒私聊类型需要安装Agent从Bot资料/原生Bot标记确认。
3. 根据已核验的CLI Bot ID、官方URL、权限和组织，用`onboard.py --input <私有输入.json> --selection <成功的selection.json> --output <私有配置.json>`生成草稿。`organization_selector_name`填写真实原生菜单名，`organization_name`保留业务企业名称。缺少明确选择记录返回`target_selection_required`；输入的Bot、profile或组织偏离选择记录返回`requested_target_mismatch`，不写配置。成功返回`entry_preparation_required`，不是安装成功。
4. 生成准备发送的文本（只落盘，不发送）：

```bash
python3 delivery/prepare_entry.py --config /absolute/private/config.json --message-output /absolute/private/renewal-entry.txt
```

文本包含固定标记 `【自动续期入口】` 和本 Bot 的官方链接。先看该私聊是否已经有匹配双 ID 的入口；有则复用，无则按用户对本次安装的授权**只发一次**。发送由登录的业务账号在已核验 Bot 私聊内完成；不依赖当前可能已过期的 Bot“发送消息”API权限。没有发送授权时，把具体目标和文本准备好后一次确认，不问抽象“能否继续”。

   已确认本机当前会话就是上述Bot私聊、且用户已授权安装入口消息时，可用分发包提供的发送命令，不再另写临时AX发送脚本：

```bash
.venv/bin/python delivery/gui.py --config /absolute/private/config.json --action seed-current-chat --evidence-dir /absolute/private/seed-1
```

   此命令明确代表一次发送请求。它不导航、不授权、不修改Bridge；先核对官方CLI身份、真实标题、聊天记录工具栏和唯一底部可编辑输入框，再保留草稿、核验焦点和完整输入、发送一次并读回匹配双ID的链接。可见入口会复用；发送结果未知会保留`.entry-send.json`并拒绝重发，Agent应查历史核实，不删除日志凑绿。标题不符返回`entry_header_mismatch`，通讯录资料页返回失败；都不能算私聊已建立。续期任务不会调用此安装命令。

5. 在本机私聊中确认消息已送出且链接完整可读，再打开链接核对同一 Bot 官方权限页。发送请求成功、另一个设备收到或 Agent 口头说已发送均不够。记录这是“新建私聊并发送入口”还是“复用已核验入口”，关闭权限页。

这条链接是长期可查找的导航入口，不是每次续期新发一条消息。不要把 Bot Secret、token 或账号密码放进消息。入口链接/ID 不进入分发 ZIP 或群内验收报告。

## 4. 离开当前会话，再验入口能否自动找回

安装 Agent 先切到另一个普通会话或另一个企业，关闭所有本轮权限页，再执行：

```bash
.venv/bin/python delivery/gui.py --config /absolute/private/config.json --action entry-verify --evidence-dir /absolute/private/entry-check-1
```

脚本使用 GUI launchd 的真实 Python，核对当前 CLI profile、原生企业选中项，从聊天历史找到双 ID 匹配链接，打开匹配的权限页、读取全部配置权限并自动关页，再核对原生组织。它不发送消息、不授权、不改变 Bridge，也不安装服务。目标页已打开或同企业目标会话仍在前台时返回 `bootstrap_cold_start_required`，不能用预先打开页面冒充自动找回。

成功后保存本设备、当前配置绑定的 `entry_receipt`，并启用已核验的组织适配器。该回执证明脚本能够找回入口；**私聊类型须由安装 Agent 在第3步从 Bot 详情进入时确认**，脚本不会把“聊天标题相同”说成私聊类型已验证。把这项观察及来源记入验收记录。换 Bot/profile/组织/权限范围/Python、CLI、Node 路径或复制配置到其他设备后，需要重新核验。

新生成的草稿缺少有效入口回执时，维护命令和定时任务生成器返回 `bootstrap_incomplete`，不会进入授权步骤。旧有生产配置不自动迁移；对旧设备升级时按此流程建立新版本私有配置，保留旧状态与回滚路径。

如果找回了正确页面，但所选权限只有“授权”按钮、没有有效期，返回 `bootstrap_authorization_baseline_required` 并关闭权限页，保留“入口已找到”的诊断。这个界面不能单独区分从未授权与已经过期；不能把它当导航失败，也不能据此静默新增权限。安装 Agent 先核对既有授权证据；新权限须完成用户确认范围内的一次首次授权，再重新运行入口核验建立有效期基线。基线具备后，后续周期才按已配置范围自动续期。

## 5. 最后才验续期和定时运行

入口验收只算“安装准备完成”。按照 AGENT-INSTALL.md 继续验证真实续期、前后有效期、关闭页面、必要的只读业务检查，再验证实际定时触发。首次需要授予的权限不能伪装成续期；没有实际到期日延长不能写“续期通过”。共用桌面的 Bridge 协调问题属于运行阶段，入口准备完成也不能消除它。

| 现象 | 回到哪一步 |
| --- | --- |
| 没有 Bot / CLI unauthorized | 第1步，完成创建或官方绑定。 |
| 找不到组织 / 页面不属于 CLI Bot | 第2步，核对原生组织与 Bot 身份；不改凭据凑数。 |
| 新设备搜不到 Bot 聊天 | 第3步，从 Bot 详情建立私聊；不重跑历史搜索。 |
| 私聊存在但没有 authorizationList 链接 | 第3步，发一次本机正确入口并读回。 |
| 已有入口但后台找不回来 | 第4步，检查导航/版本/实际 Python 系统权限，不重复发消息。 |
| 权限显示从未授权 | 完成用户确认范围内的首次授权，单独记录，再验续期。 |
| entry-verify 通过，maintain 仍失败 | 排查具体运行阶段，保留入口成果；不重建 Bot、不重置 CLI。 |

## 用户明确同意首次权限后

仅在用户已批准配置target_rows中的每一项首次授权时，安装Agent运行：

```bash
.venv/bin/python delivery/gui.py --config /absolute/private/config.json --action initial-grant --evidence-dir /absolute/private/initial-grant-1
```

该动作先核对官方CLI身份，持共同桌面锁、校验Bridge协调，再打开双ID绑定页，只为配置范围建立授权基线；已有健康权限不取消，结束自动关页。它不生成入口成功回执，不代表真实续期；之后离开会话重新entry-verify，再验实际有效期延长与自然定时。首次批准不扩展到未配置权限，不修改凭据或其他服务。
