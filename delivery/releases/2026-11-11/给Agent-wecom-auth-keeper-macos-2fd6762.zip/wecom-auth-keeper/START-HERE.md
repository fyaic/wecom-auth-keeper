# 企业微信 Bot 自动续期安装包

**使用者先读 [中文简短说明](delivery/USER-GUIDE.txt)**；安装 Agent 从根 [AGENTS.md](AGENTS.md) 和 [执行清单](delivery/AGENT-RUNBOOK.md) 开始。

解压到固定位置，把整个文件夹交给能操作本机文件、终端和企业微信的 Codex、WorkBuddy 或 Kimi。说明中已有可复制的安装指令，业务人员无需准备ID、Secret或命令。

当前新设备接入适配企业微信 **5.0.13中文版 / macOS**；电脑需登录Bot创建者主账号，保持开机、登录和桌面可操作。首次安装需要联网下载依赖，可能需要一次系统权限或首次业务权限确认。Windows暂不支持，旧企业微信版本需对应适配和实测。

日常由Python和系统定时任务每小时检查，在到期前24小时按各权限期限续期，结束自动关页。可以配置多项权限、多Bot分别部署；本轮远端真实续期验证仅覆盖发送消息。每个新设备由Agent验收后启用，安装完成应提供本机结果卡与持久停用方式。

- [安装协议与持久任务](delivery/AGENT-INSTALL.md)
- [首次Bot、组织与本机私聊准备](delivery/FIRST-RUN.md)
- [实测结果与支持边界](delivery/VALIDATION.md)
- [共用企业微信桌面的服务](delivery/BRIDGE-COORDINATION.md)

Kimi已完成指定远端的实际演练；WorkBuddy本轮未实机验证。运行不需要AI常驻，安装辅助与日常脚本执行的证据分别记录。
