# Agent entry point

When asked to install this project for a business user, follow
[delivery/AGENT-RUNBOOK.md](delivery/AGENT-RUNBOOK.md), read
[delivery/AGENT-INSTALL.md](delivery/AGENT-INSTALL.md) and
[delivery/FIRST-RUN.md](delivery/FIRST-RUN.md) before running renewal commands.
For the business user, use [delivery/USER-GUIDE.txt](delivery/USER-GUIDE.txt).
Respect authorization already given in this session; routine inspection and
reversible fixes do not need repeated permission questions.

This is a macOS Agent installation package requiring acceptance on each device.
The remote Kimi rehearsal has verified real script renewal and a natural timer
trigger on WeCom 5.0.13/95049 CN; see delivery/VALIDATION.md for exact limits.
Windows has no automation backend. Do not describe package integrity, unit tests
or a healthy permission page as proof of successful unattended renewal.

Installation order:

0. Record the user's requested Bot and organization first. Explicit user intent
   outranks a business service's profile and the terminal default. Never replace
   a requested test Bot with an authorized default business Bot. This distribution supports a desktop logged in as the Bot creator's primary
   account, maintaining Bots created by that account. Existing CLI credentials
   alone do not satisfy this requirement. Establish it from the existing CLI and
   official UI identity before enabling maintenance; preserve bindings and stop
   installation on a creator rejection. Do not switch the login of a desktop
   used by another service without the user's authorization.
1. Inventory known CLI profiles with `delivery/profiles.py`. Use official CLI
   identity reads; do not read credentials or replace another Bot's binding.
   An authorized default profile is only a candidate, never an automatic target.
   Expiry (`850003`), missing chat history, a renamed Bot or an unverified desktop
   identity never justifies `auth init`, a new profile or a QR code. Only a
   genuinely missing target binding with a confirmed setup request uses first-time setup.
   For an already-created API Bot, inspect its own official API configuration and
   the CLI's manual setup option before requesting a QR scan. Existing credentials
   may be handled locally for that authorized setup, never exposed to the model,
   arguments or logs; never decrypt another profile or reset a Secret to fix navigation.
   Read the bound page's completed response before proceeding: a creator or
   organization rejection is an identity/access blocker, not a missing button.
   Preserve the existing binding; do not attempt to fix it by initializing again.
2. Verify the requested Bot's organization using the native enterprise menu and the Bot's
   official identity. “Manage robots” is not the complete list of usable Bots.
   On WeCom 5.0.13, “查看更多机器人” opens the contacts Bot directory.
   If absent, use “更多 → 通讯录 → 智能机器人”; sidebar positions vary
   between organizations, and “更多” can be outside the function-row table.
   Use config-free `gui.py --action inspect-expanded --python <absolute-python>`
   with a new private evidence directory before Bot IDs are available; never
   fabricate IDs just to run diagnostics.
   Record the requested Bot's actual native permission-page identity, then run
   `select_target.py` against the profile inventory. No match means this target's
   CLI preparation is unresolved, not that the entire device lacks creator
   access. Multiple matches require an explicit profile choice. Only a matched
   selection may feed `existing_entry.py --selection ...` and `onboard.py
   --selection ...`. Keep the original official URL parameters. Do not use an
   error from another Bot to reject the requested Bot or send the user elsewhere.
3. Open this account's private conversation from the verified Bot's details.
   On 5.0.13, “去使用” can first open the contacts Bot profile; then use that
   profile's “发消息” navigation button. A selected contacts row, global search
   or any AXTextArea is not a conversation/composer. Verify the actual message
   view, header and composer before sending; use the observed AX header from
   inspect-expanded, not screenshot spacing. Use seed-current-chat for the
   authorized one-time entry, preserving drafts and unknown-send journals; never use “添加到群聊”.
   If the permission page is accessible only through a conversation, you may
   first open an empty candidate conversation from a native Bot directory row
   for read-only identity inspection. Do not send or authorize until it matches.
   A new device may have no conversation or renewal link. Prepare and, within the
   user's authorization, send one entry link there; read it back locally. Do not
   send it to a group or another Bot, or search for history that does not exist.
4. Leave the conversation, then use the GUI launchd entry verifier to reopen the
   correct page, read the selected permissions and close it. Preserve its result
   separately from the installer's observation of the private-chat type.
5. Verify real expiry extension by scripts, then a real scheduled trigger, before
   enabling the production schedule. Report entry preparation, renewal and
   scheduling separately. Never delete an entry-receipt requirement to bypass it.

Business users should not need to supply IDs, Secrets or shell commands. Discover
what the device can tell you, and ask only about unresolved business choices or
necessary one-time system/first-access authorization. Respect existing service
constraints; in particular, do not stop or change a Bridge without authorization.
Do not contact others or upload private diagnostics as part of installation.

For repository development, keep real configs and acceptance evidence outside
the release. Build the ZIP with `delivery/build_bundle.py` from committed files;
verify the manifest after extraction and retain the exact tested commit. Runtime
changes require relevant regression tests; live device acceptance remains a
separate requirement. See [delivery/VALIDATION.md](delivery/VALIDATION.md).
